import UIKit

class EmailViewController: UIViewController, UITextFieldDelegate {

    // Define the text field for email input
    var emailTextField: UITextField!
    
    // Create the custom domain suggestion view
    var domainSuggestionView: UIView!
    
    // List of common email domains
    let emailDomains = ["gmail.com", "yahoo.com", "outlook.com", "icloud.com"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Setup the email text field
        setupEmailTextField()
        
        // Setup the custom domain suggestion view
        setupDomainSuggestionView()
        
        // Register for keyboard notifications
        registerForKeyboardNotifications()
    }
    
    func setupEmailTextField() {
        // Create and configure the email text field
        emailTextField = UITextField()
        emailTextField.placeholder = "Enter email address"
        emailTextField.delegate = self
        emailTextField.borderStyle = .roundedRect
        emailTextField.frame = CGRect(x: 20, y: 100, width: 300, height: 40)
        
        view.addSubview(emailTextField)
    }
    
    func setupDomainSuggestionView() {
        // Create a custom view to display domain suggestions
        domainSuggestionView = UIView()
        domainSuggestionView.backgroundColor = .lightGray
        domainSuggestionView.isHidden = true // Initially hidden
        
        // Create a stack view to hold the domain buttons
        let stackView = UIStackView()
        stackView.axis = .horizontal
        stackView.spacing = 10
        stackView.alignment = .center
        stackView.distribution = .fillEqually
        
        // Add buttons for each domain
        for domain in emailDomains {
            let button = UIButton(type: .system)
            button.setTitle(domain, for: .normal)
            button.addTarget(self, action: #selector(domainButtonTapped(_:)), for: .touchUpInside)
            stackView.addArrangedSubview(button)
        }
        
        domainSuggestionView.addSubview(stackView)
        stackView.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            stackView.leadingAnchor.constraint(equalTo: domainSuggestionView.leadingAnchor, constant: 10),
            stackView.trailingAnchor.constraint(equalTo: domainSuggestionView.trailingAnchor, constant: -10),
            stackView.topAnchor.constraint(equalTo: domainSuggestionView.topAnchor, constant: 10),
            stackView.bottomAnchor.constraint(equalTo: domainSuggestionView.bottomAnchor, constant: -10)
        ])
        
        domainSuggestionView.frame = CGRect(x: 0, y: view.frame.height, width: view.frame.width, height: 50)
        view.addSubview(domainSuggestionView)
    }
    
    @objc func domainButtonTapped(_ sender: UIButton) {
        // Add the domain to the email text field
        if let domain = sender.title(for: .normal), let text = emailTextField.text {
            emailTextField.text = text + "@" + domain
        }
        
        // Hide the domain suggestion view after a selection
        //domainSuggestionView.isHidden = true
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        // Show the domain suggestion view when the user starts editing the email field
        domainSuggestionView.isHidden = false
    }
    
    // Handle keyboard appearance and reposition domain suggestion view
    func registerForKeyboardNotifications() {
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(notification:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(notification:)), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    @objc func keyboardWillShow(notification: Notification) {
        // Move the domain suggestion view above the keyboard
        if let userInfo = notification.userInfo,
           let keyboardFrame = userInfo[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect {
            let keyboardHeight = keyboardFrame.height
            UIView.animate(withDuration: 0.3) {
                self.domainSuggestionView.frame.origin.y = self.view.frame.height - keyboardHeight - self.domainSuggestionView.frame.height
            }
        }
    }
    
    @objc func keyboardWillHide(notification: Notification) {
        // Hide the domain suggestion view when the keyboard is dismissed
        UIView.animate(withDuration: 0.3) {
            self.domainSuggestionView.frame.origin.y = self.view.frame.height
        }
    }
    
    deinit {
        // Unregister from notifications when the view controller is deallocated
        NotificationCenter.default.removeObserver(self)
    }
}
