//
//  EmailDomainView.swift
//  SampleTestProject
//
//  Created by Bharathi's Macbook Air on 16/12/24.
//

import Foundation
import UIKit

class EmailDomainView: UIView, UIScrollViewDelegate {

    private lazy var scrollView: UIScrollView = {
        let scrollView = UIScrollView()
        scrollView.delegate = self
        return scrollView
    }()

    private lazy var contentView: UIView = {
        let contentView = UIView()
        return contentView
    }()

    private var domainLabels = [UILabel]()

    override init(frame: CGRect) {
        super.init(frame: frame)
        setupUI()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setupUI() {
        addSubview(scrollView)
        scrollView.addSubview(contentView)

        // ... other UI setup ...

        // Set up constraints for scrollView and contentView
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        contentView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            scrollView.topAnchor.constraint(equalTo: topAnchor),
            scrollView.leadingAnchor.constraint(equalTo: leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: trailingAnchor),
            scrollView.bottomAnchor.constraint(equalTo: bottomAnchor),

            contentView.topAnchor.constraint(equalTo: scrollView.topAnchor),
            contentView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor),
            contentView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor),
            contentView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor),
        ])

        // Configure scrollView
        scrollView.showsVerticalScrollIndicator = false
        scrollView.showsHorizontalScrollIndicator = false
    }

    // Function to add a new domain label
    func addDomain(domain: String) {
        let label = UILabel()
        label.text = domain
        label.textColor = .black
        label.font = UIFont.systemFont(ofSize: 16)

        contentView.addSubview(label)
        domainLabels.append(label)

        // Update contentView's height constraint to accommodate the new label
        let totalHeight = domainLabels.reduce(0) { $0 + $1.intrinsicContentSize.height }
        contentView.heightAnchor.constraint(equalToConstant: totalHeight).isActive = true

        // Update scrollView's content size
        scrollView.contentSize = contentView.frame.size
    }

    // ... InputAccessoryView protocol implementation ...
}
