import UIKit

extension UITextField: UITableViewDelegate, UITableViewDataSource {

    // Private properties to handle the table view
    private struct AssociatedKeys {
        static var suggestionsTableView = "suggestionsTableView"
    }

    private var suggestionsTableView: UITableView? {
        get {
            return objc_getAssociatedObject(self, &AssociatedKeys.suggestionsTableView) as? UITableView
        }
        set {
            objc_setAssociatedObject(self, &AssociatedKeys.suggestionsTableView, newValue, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
        }
    }

    private var domainSuggestions: [String] {
        return ["gmail.com", "yahoo.com", "hotmail.com", "outlook.com", "icloud.com", "aol.com", "google.com", "proton.com", "asl.com", "hotstar.com"]
    }

    // Setup function to add UITableView below the UITextField
    func setupEmailDomainSuggestionsTable() {
        guard suggestionsTableView == nil else { return } // Prevent multiple setup calls
        
        let tableView = UITableView()
        tableView.frame = CGRect(x: self.frame.origin.x, y: self.frame.origin.y + self.frame.height, width: self.frame.width, height: 200)
        tableView.delegate = self
        tableView.dataSource = self
        tableView.isHidden = true
        self.superview?.addSubview(tableView)
        self.suggestionsTableView = tableView
    }

    // Detect when user types the @ symbol
    func handleTextChanged() {
        guard let text = self.text else { return }
        
        // Show suggestions only after '@' is typed
        if let atIndex = text.firstIndex(of: "@") {
            let domainPrefix = text[text.index(after: atIndex)...]
            let filteredDomains = domainSuggestions.filter { $0.hasPrefix(String(domainPrefix)) }
            self.showSuggestions(filteredDomains)
        } else {
            self.hideSuggestions()
        }
    }

    // Show or update the suggestions in the table view
    private func showSuggestions(_ domains: [String]) {
        guard let tableView = suggestionsTableView else { return }
        tableView.isHidden = false
        
        // Update table view data
        tableView.reloadData()
    }

    // Hide suggestions if no '@' or if list is empty
    private func hideSuggestions() {
        suggestionsTableView?.isHidden = true
    }

    // UITableView Delegate & DataSource methods
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard let text = self.text, let atIndex = text.firstIndex(of: "@") else { return 0 }
        
        let domainPrefix = text[text.index(after: atIndex)...]
        let filteredDomains = domainSuggestions.filter { $0.hasPrefix(String(domainPrefix)) }
        
        return filteredDomains.count
    }

    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DomainCell") ?? UITableViewCell(style: .default, reuseIdentifier: "DomainCell")
        
        guard let text = self.text, let atIndex = text.firstIndex(of: "@") else { return cell }
        
        let domainPrefix = text[text.index(after: atIndex)...]
        let filteredDomains = domainSuggestions.filter { $0.hasPrefix(String(domainPrefix)) }
        
        cell.textLabel?.text = filteredDomains[indexPath.row]
        
        return cell
    }

    // Handle the selection of a domain
    public func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let text = self.text, let atIndex = text.firstIndex(of: "@") else { return }
        
        var domainPrefix = text[text.index(after: atIndex)...]
        let filteredDomains = domainSuggestions.filter { $0.hasPrefix(String(domainPrefix)) }
        
        if let domain = filteredDomains[safe: indexPath.row] {
            self.text = text.prefix(upTo: atIndex) + "@" + domain
            hideSuggestions()
        }
    }

//    // Override UITextField's initialization methods
//    required public init?(coder: NSCoder) {
//        super.init(coder: coder)
//        commonInit()
//    }
//
//    override public init(frame: CGRect) {
//        super.init(frame: frame)
//        commonInit()
//    }

    // Common initialization for both frame-based and storyboard-based instances
    func commonInit() {
        // Add target for editing changes
        self.addTarget(self, action: #selector(textFieldDidChange), for: .editingChanged)
        setupEmailDomainSuggestionsTable()
    }

    @objc private func textFieldDidChange() {
        handleTextChanged()
    }
}

// Helper extension to safely access array index
extension Collection {
    subscript(safe index: Index) -> Element? {
        return indices.contains(index) ? self[index] : nil
    }
}
