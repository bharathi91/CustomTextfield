import UIKit

class Autocomplete2ViewController: UIViewController, UITextFieldDelegate {

    var emailTextField: UITextField!

    // Sample suggestions
    let suggestions = ["gmail", "outlook", "proton", "icloud", "yahoo"]

    override func viewDidLoad() {
        super.viewDidLoad()
        let emailTextField = UITextField(frame: CGRect(x: 20, y: 100, width: self.view.frame.width - 40, height: 40))
        emailTextField.placeholder = "Enter email address"
        emailTextField.borderStyle = .roundedRect
        self.view.addSubview(emailTextField)
        emailTextField.commonInit()
        emailTextField.setupEmailDomainSuggestionsTable()
    }
//    func setupEmailTextField() {
//        // Create and configure the email text field
//        emailTextField = UITextField()
//        emailTextField.placeholder = "Enter email address"
//        emailTextField.delegate = self
//        emailTextField.borderStyle = .roundedRect
//        emailTextField.delegate = self
//        emailTextField.frame = CGRect(x: 20, y: 100, width: 300, height: 40)
//        emailTextField.suggestions = suggestions
//        emailTextField.delimiter = "@"
//        view.addSubview(emailTextField)
//    }
//
//    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
//        let newText = (textField.text as NSString?)?.replacingCharacters(in: range, with: string) ?? ""
//
//        // Filter suggestions based on newText
//        let filteredSuggestions = suggestions.filter { $0.hasPrefix(newText) }
//
//        // Update the text field's appearance to show the first suggestion
//        if let firstSuggestion = filteredSuggestions.first {
//            let attributedString = NSMutableAttributedString(string: newText)
//            let suggestionString = firstSuggestion.suffix(firstSuggestion.count - newText.count)
//            let suggestionAttributedString = NSMutableAttributedString(string: String(suggestionString))
//            suggestionAttributedString.addAttribute(.foregroundColor, value: UIColor.gray, range: NSRange(location: 0, length: suggestionString.count))
//            attributedString.append(suggestionAttributedString)
//            textField.attributedText = attributedString
//        } else {
//            textField.attributedText = nil
//        }
//
//        return true
//    }
}
