import SwiftUI

struct CustomButton: View {
    var title: String
    var action: () -> Void
    var backgroundColor: Color = .blue
    var foregroundColor: Color = .white
    var cornerRadius: CGFloat = 10
    @State private var isPressed = false

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.headline)
                .foregroundColor(foregroundColor)
                .padding()
                .frame(maxWidth: .infinity)
                .background(backgroundColor)
                .cornerRadius(cornerRadius)
                .shadow(radius: 5)
                .scaleEffect(isPressed ? 0.80 : 1)
                .animation(.spring(), value: isPressed)
        }.onLongPressGesture(minimumDuration: 0.1, pressing: { isPressing in
            isPressed = isPressing
        }, perform: {})
    }
}

struct CustomButton_Previews: PreviewProvider {
    static var previews: some View {
        CustomButton(title: "Click Me", action: { print("Button tapped!") })
            .previewLayout(.sizeThatFits)
    }
}
