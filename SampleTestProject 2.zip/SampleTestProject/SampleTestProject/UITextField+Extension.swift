//import UIKit
//
//// Define an extension for UITextField
//extension UITextField {
//
//    // Property to store the reference to the custom domain suggestion view
//    private struct AssociatedKeys {
//        static var domainSuggestionView = "domainSuggestionView"
//    }
//    
//    private var domainSuggestionView: UIView? {
//        get {
//            return objc_getAssociatedObject(self, &AssociatedKeys.domainSuggestionView) as? UIView
//        }
//        set {
//            objc_setAssociatedObject(self, &AssociatedKeys.domainSuggestionView, newValue, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
//        }
//    }
//    
//    // List of email domains to suggest
//    private var emailDomains: [String] {
//        return ["gmail.com", "yahoo.com", "outlook.com", "icloud.com"]
//    }
//    
//    // Method to show the domain suggestion view
//    func showDomainSuggestions() {
//        // Create the domain suggestion view if it doesn't exist
//        if domainSuggestionView == nil {
//            let suggestionView = createDomainSuggestionView()
//            self.inputAccessoryView = suggestionView
//            domainSuggestionView = suggestionView
//        }
//        
//        // Make sure the domain suggestion view is visible when editing
//        domainSuggestionView?.isHidden = false
//    }
//    
//    // Method to hide the domain suggestion view
//    func hideDomainSuggestions() {
//        domainSuggestionView?.isHidden = true
//    }
//    
//    // Method to create the domain suggestion view (this is the same code as before)
//    private func createDomainSuggestionView() -> UIView {
//        // Create the custom view to display domain suggestions
//        let suggestionView = UIView()
//        suggestionView.backgroundColor = .lightGray
//        suggestionView.isHidden = true
//        
//        // Create a stack view to hold the domain buttons
//        let stackView = UIStackView()
//        stackView.axis = .horizontal
//        stackView.spacing = 10
//        stackView.alignment = .center
//        stackView.distribution = .fillEqually
//        
//        // Add buttons for each domain
//        for domain in emailDomains {
//            let button = UIButton(type: .system)
//            button.setTitle(domain, for: .normal)
//            button.addTarget(self, action: #selector(domainButtonTapped(_:)), for: .touchUpInside)
//            stackView.addArrangedSubview(button)
//        }
//        
//        suggestionView.addSubview(stackView)
//        stackView.translatesAutoresizingMaskIntoConstraints = false
//        
//        NSLayoutConstraint.activate([
//            stackView.leadingAnchor.constraint(equalTo: suggestionView.leadingAnchor, constant: 10),
//            stackView.trailingAnchor.constraint(equalTo: suggestionView.trailingAnchor, constant: -10),
//            stackView.topAnchor.constraint(equalTo: suggestionView.topAnchor, constant: 10),
//            stackView.bottomAnchor.constraint(equalTo: suggestionView.bottomAnchor, constant: -10)
//        ])
//        
//        suggestionView.frame.size.height = 50 // Set a fixed height for the suggestion view
//        suggestionView.frame.origin.y = self.superview?.frame.height ?? 400 // Ensure the suggestion view is initially at the top
//        
//        return suggestionView
//    }
//    
//    // Action triggered when a domain button is tapped
//    @objc private func domainButtonTapped(_ sender: UIButton) {
//        if let domain = sender.title(for: .normal), let currentText = self.text {
//            self.text = currentText + "@" + domain
//        }
//        
//        // Hide the domain suggestion view after a selection
//        hideDomainSuggestions()
//    }
//    
//    // Observe keyboard notifications for dynamic repositioning
//    func registerForKeyboardNotifications() {
//        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(notification:)), name: UIResponder.keyboardWillShowNotification, object: nil)
//        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(notification:)), name: UIResponder.keyboardWillHideNotification, object: nil)
//    }
//    
//    @objc private func keyboardWillShow(notification: Notification) {
//        if let suggestionView = domainSuggestionView, !suggestionView.isHidden {
//            if let userInfo = notification.userInfo,
//               let keyboardFrame = userInfo[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect {
//                let keyboardHeight = keyboardFrame.height
//                
//                UIView.animate(withDuration: 0.3) {
//                    // Adjust the position of the domain suggestion view above the keyboard
//                    suggestionView.frame.origin.y = (self.superview?.frame.height ?? 300) -  keyboardHeight - 500
//                }
//            }
//        }
//    }
//    
//    @objc private func keyboardWillHide(notification: Notification) {
//        if let suggestionView = domainSuggestionView {
//            UIView.animate(withDuration: 0.3) {
//                // Reset the domain suggestion view's position after the keyboard hides
//                suggestionView.frame.origin.y = 0
//            }
//        }
//    }
//    
////    // Deinitialize the observers when the text field is deallocated
////    deinit {
////        NotificationCenter.default.removeObserver(self)
////    }
//}
