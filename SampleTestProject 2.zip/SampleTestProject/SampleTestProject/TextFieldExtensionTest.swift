//
//  TextFieldExtensionTest.swift
//  SampleTestProject
//
//  Created by Bharathi's Macbook Air on 18/12/24.
//

import UIKit

class TextFieldExtensionTest: UIViewController {
    
    let textField = UITextField()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Setup the UITextField
        textField.frame = CGRect(x: 20, y: 100, width: self.view.frame.width - 40, height: 40)
        textField.layer.borderWidth = 1
        textField.layer.borderColor = UIColor.gray.cgColor
        textField.font = UIFont.systemFont(ofSize: 16)
        textField.autocorrectionType = .no
        textField.placeholder = "Enter email"
        view.addSubview(textField)
        
        // Setup email domains and autocomplete
        //textField.setupEmailAutocomplete(with: ["gmail.com", "yahoo.com", "hotmail.com", "outlook.com", "icloud.com"])
    }
}
