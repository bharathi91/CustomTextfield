import UIKit

extension UITextField {

    private struct AssociatedKeys {
        static var domainSuggestionView = "domainSuggestionView"
    }

    private var domainSuggestionView: UIView? {
        get {
            return objc_getAssociatedObject(self, &AssociatedKeys.domainSuggestionView) as? UIView
        }
        set {
            objc_setAssociatedObject(self, &AssociatedKeys.domainSuggestionView, newValue, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
        }
    }
    
    private var emailDomains: [String] {
        return ["gmail.com", "yahoo.com", "outlook.com", "icloud.com", "hotmail.com", "aol.com", "zoho.com", "protonmail.com", "mail.com", "gmx.com"]
    }

    // Show domain suggestions view
    func showDomainSuggestions() {
        if domainSuggestionView == nil {
            let suggestionView = createDomainSuggestionView()
            self.inputAccessoryView = suggestionView
            domainSuggestionView = suggestionView
        }
        
        domainSuggestionView?.isHidden = false
    }

    // Hide the domain suggestions view
    func hideDomainSuggestions() {
        domainSuggestionView?.isHidden = true
    }

    private func createDomainSuggestionView() -> UIView {
        // Create the suggestion view (this will be the input accessory view)
        let suggestionView = UIView()
        suggestionView.backgroundColor = .lightGray
        suggestionView.isHidden = false
        
        // Create the scroll view that will contain the domain buttons
        let scrollView = UIScrollView()
        scrollView.showsHorizontalScrollIndicator = false
        scrollView.showsVerticalScrollIndicator = true
        scrollView.translatesAutoresizingMaskIntoConstraints = false
        
        // Create a stack view to hold the domain buttons
        let stackView = UIStackView()
        stackView.axis = .vertical
        stackView.spacing = 10
        stackView.alignment = .leading
        stackView.distribution = .fill
        
        // Add buttons for each domain
        for domain in emailDomains {
            let button = UIButton(type: .system)
            button.setTitle(domain, for: .normal)
            button.addTarget(self, action: #selector(domainButtonTapped(_:)), for: .touchUpInside)
            stackView.addArrangedSubview(button)
        }

        // Add stack view to scroll view
        scrollView.addSubview(stackView)

        // Set up constraints for stack view inside the scroll view
        NSLayoutConstraint.activate([
            stackView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor),
            stackView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor),
            stackView.topAnchor.constraint(equalTo: scrollView.topAnchor),
            stackView.bottomAnchor.constraint(equalTo: scrollView.bottomAnchor),
            stackView.widthAnchor.constraint(equalTo: scrollView.widthAnchor) // Ensures scroll view scrolls vertically
        ])

        // Add the scroll view to the suggestion view
        suggestionView.addSubview(scrollView)

        // Set constraints for scroll view inside the suggestion view
        NSLayoutConstraint.activate([
            scrollView.leadingAnchor.constraint(equalTo: suggestionView.leadingAnchor),
            scrollView.trailingAnchor.constraint(equalTo: suggestionView.trailingAnchor),
            scrollView.topAnchor.constraint(equalTo: suggestionView.topAnchor),
            scrollView.bottomAnchor.constraint(equalTo: suggestionView.bottomAnchor),
        ])

        // No need to manually set frame here; Auto Layout will handle positioning

        return suggestionView
    }

    // Handle button tap
    @objc private func domainButtonTapped(_ sender: UIButton) {
        if let domain = sender.title(for: .normal), let currentText = self.text {
            self.text = currentText + "@" + domain
        }

        hideDomainSuggestions()
    }

    // Register for keyboard notifications
    func registerForKeyboardNotifications() {
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(notification:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(notification:)), name: UIResponder.keyboardWillHideNotification, object: nil)
    }

    @objc private func keyboardWillShow(notification: Notification) {
        if let suggestionView = domainSuggestionView, !suggestionView.isHidden {
            if let userInfo = notification.userInfo,
               let keyboardFrame = userInfo[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect {
                let keyboardHeight = keyboardFrame.height
                
                UIView.animate(withDuration: 0.3) {
                    // Adjust position based on keyboard height
                    suggestionView.frame = CGRect(x: 0, y: 200, width: self.superview?.frame.width ?? 300, height: 50)
                }
            }
        }
    }

//    @objc private func keyboardWillHide(notification: Notification) {
//        if let suggestionView = domainSuggestionView {
//            UIView.animate(withDuration: 0.3) {
//                suggestionView.frame.origin.y = 0
//            }
//        }
//    }
    @objc private func keyboardWillHide(notification: Notification) {
      if let suggestionView = domainSuggestionView {
        let size = suggestionView.systemLayoutSizeFitting(UIView.layoutFittingCompressedSize)
        UIView.animate(withDuration: 0.3) {
          suggestionView.frame.origin.y = self.frame.origin.y - size.height
        }
      }
    }
//    // Deinit to remove observers
//    deinit {
//        NotificationCenter.default.removeObserver(self)
//    }
}
