//
//  TextFieldExtensioTestVC.swift
//  SampleTestProject
//
//  Created by Bharathi's Macbook Air on 17/12/24.
//

import UIKit

import UIKit

class TextFieldExtensioTestVC: UIViewController, UITextFieldDelegate {

    // Define the email text field
    var emailTextField: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Setup the email text field
        setupEmailTextField()

        // Register for keyboard notifications
        emailTextField.registerForKeyboardNotifications()
    }

    func setupEmailTextField() {
        // Create the email text field
        emailTextField = UITextField()
        emailTextField.placeholder = "Enter email address"
        emailTextField.borderStyle = .roundedRect
        emailTextField.frame = CGRect(x: 20, y: 100, width: 300, height: 40)
        
        // Set the delegate to self
        emailTextField.delegate = self
        
        // Add the text field to the view
        view.addSubview(emailTextField)
    }

    func textFieldDidBeginEditing(_ textField: UITextField) {
        // Show domain suggestions when editing begins
        emailTextField.showDomainSuggestions()
    }

    func textFieldDidEndEditing(_ textField: UITextField) {
        // Hide domain suggestions when editing ends
        emailTextField.hideDomainSuggestions()
    }
}
