//
//  DashboardVC.swift
//  SampleTestProject
//
//  Created by Bharathi's Macbook Air on 12/12/24.
//

import UIKit
import SwiftUI
class DashboardVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Sample Page"
        let swiftUIButton = CustomButton(title: "Tap me!", action: {
            print("Button tapped in UIKit!")
        })
        
        // Embed the SwiftUI button into UIKit using UIHostingController
        let hostingController = UIHostingController(rootView: swiftUIButton)
        
        // Add the hosting controller as a child
        addChild(hostingController)
        hostingController.view.frame = CGRect(x: 50, y: 100, width: 300, height: 60)  // Set the position and size
        view.addSubview(hostingController.view)
        hostingController.didMove(toParent: self)
    }
}
