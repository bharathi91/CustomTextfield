//import UIKit
//
//public enum SuggestionType {
//    case Word
//    case Sentence
//}
//
//public extension UITextField {
//
//    // MARK: - public properties
//
//    private struct AssociatedKeys {
//        static var suggestions = "suggestions"
//        static var suggestionColor = "suggestionColor"
//        static var suggestion = "suggestion"
//        static var pixelCorrections = "pixelCorrections"
//        static var suggestionType = "suggestionType"
//        static var horizontalPadding = "horizontalPadding"
//        static var delimiter = "delimiter"
//        static var suggestionList = "suggestionList"
//        static var label = "label"
//    }
//
//    var suggestions: [String] {
//        get {
//            return objc_getAssociatedObject(self, &AssociatedKeys.suggestions) as? [String] ?? []
//        }
//        set {
//            objc_setAssociatedObject(self, &AssociatedKeys.suggestions, newValue, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
//            suggestionList = allSuggestions()
//        }
//    }
//
//    @IBInspectable var suggestionColor: UIColor {
//        get {
//            return objc_getAssociatedObject(self, &AssociatedKeys.suggestionColor) as? UIColor ?? UIColor(white: 0, alpha: 0.22)
//        }
//        set {
//            objc_setAssociatedObject(self, &AssociatedKeys.suggestionColor, newValue, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
//        }
//    }
//
//    private(set) var suggestion: String? {
//        get {
//            return objc_getAssociatedObject(self, &AssociatedKeys.suggestion) as? String
//        }
//        set {
//            objc_setAssociatedObject(self, &AssociatedKeys.suggestion, newValue, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
//            setLabelText(text: newValue)
//        }
//    }
//
//    var pixelCorrections: CGPoint {
//        get {
//            return objc_getAssociatedObject(self, &AssociatedKeys.pixelCorrections) as? CGPoint ?? .zero
//        }
//        set {
//            objc_setAssociatedObject(self, &AssociatedKeys.pixelCorrections, newValue, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
//        }
//    }
//
//    var suggestionType: SuggestionType {
//        get {
//            return objc_getAssociatedObject(self, &AssociatedKeys.suggestionType) as? SuggestionType ?? .Sentence
//        }
//        set {
//            objc_setAssociatedObject(self, &AssociatedKeys.suggestionType, newValue, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
//        }
//    }
//
//    var horizontalPadding: CGFloat {
//        get {
//            return objc_getAssociatedObject(self, &AssociatedKeys.horizontalPadding) as? CGFloat ?? 0
//        }
//        set {
//            objc_setAssociatedObject(self, &AssociatedKeys.horizontalPadding, newValue, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
//        }
//    }
//
//    var delimiter: String? {
//        get {
//            return objc_getAssociatedObject(self, &AssociatedKeys.delimiter) as? String
//        }
//        set {
//            objc_setAssociatedObject(self, &AssociatedKeys.delimiter, newValue, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
//        }
//    }
//
//    private var suggestionList: [String] {
//        get {
//            return objc_getAssociatedObject(self, &AssociatedKeys.suggestionList) as? [String] ?? []
//        }
//        set {
//            objc_setAssociatedObject(self, &AssociatedKeys.suggestionList, newValue, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
//        }
//    }
//
//    private var label: UILabel {
//        get {
//            return objc_getAssociatedObject(self, &AssociatedKeys.label) as? UILabel ?? {
//                let label = UILabel()
//                self.addSubview(label)
//                objc_setAssociatedObject(self, &AssociatedKeys.label, label, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
//                return label
//            }()
//        }
//    }
//
//    // MARK: - Initialization
//
////    override func awakeFromNib() {
////        super.awakeFromNib()
////        self.setup()
////    }
//
//    private func setup() {
//        self.addTarget(self, action: #selector(autocompleteFieldDidChange(_:)), for: .editingChanged)
//        createAutocompleteLabel()
//    }
//
//    private func createAutocompleteLabel() {
//        label.lineBreakMode = .byClipping
//        setPadding()
//    }
//
//    private func setPadding() {
//        if borderStyle == .roundedRect || borderStyle == .bezel || borderStyle == .line {
//            horizontalPadding = 8
//        }
//    }
//
//    // MARK: - Methods for Autocompletion
//
//    private func allSuggestions() -> [String] {
//        if suggestionType == .Sentence {
//            return suggestions
//        }
//
//        var wordSuggestions: [String] = []
//        for suggestion in suggestions {
//            let components = suggestion.components(separatedBy: " ")
//            for count in 0..<components.count {
//                var name = ""
//                for i in 0...count {
//                    if i > 0 {
//                        name.append(" ")
//                    }
//                    name.append(components[i])
//                }
//                wordSuggestions.append(name)
//            }
//        }
//
//        return wordSuggestions.sorted { $0.count < $1.count }
//    }
//
//    private func splitTextByDelimiter(text: String, delimiter: String) -> [String] {
//        var parts = text.components(separatedBy: delimiter)
//        if parts.count > 1 {
//            parts.removeFirst()
//            return [parts[0], parts.dropFirst().joined(separator: delimiter)]
//        }
//        return parts
//    }
//
//    private func getSuggestion(text: String?) -> String? {
//        guard var inputText = text, !inputText.isEmpty else {
//            return nil
//        }
//
//        if let delimiterText = delimiter {
//            let parts = splitTextByDelimiter(text: inputText, delimiter: delimiterText)
//            if parts.count > 1 {
//                inputText = parts[1]
//            } else {
//                return nil
//            }
//        }
//
//        return suggestionList.first { $0.hasPrefix(inputText) }
//    }
//
//    private func setLabelText(text: String?) {
//        guard let labelText = text, let inputText = self.text, inputText.count < labelText.count else {
//            label.attributedText = nil
//            return
//        }
//
//        let attributedString = NSMutableAttributedString(string: labelText)
//        let range = NSRange(location: 0, length: labelText.count)
//        attributedString.addAttributes(self.defaultTextAttributes, range: range)
//        attributedString.addAttribute(.foregroundColor, value: suggestionColor, range: range)
//
//        if inputText.count > 0 {
//            attributedString.addAttribute(.foregroundColor, value: UIColor.clear, range: NSRange(location: 0, length: inputText.count))
//        }
//
//        label.attributedText = attributedString
//        label.textAlignment = self.textAlignment
//    }
//
//    // MARK: - Event Handlers
//
//    @objc func autocompleteFieldDidChange(_ textField: UITextField) {
//        guard let text = textField.text else { return }
//
//        if var suggestion = getSuggestion(text: text) {
//            if let delimiter = self.delimiter {
//                let prefix = splitTextByDelimiter(text: text, delimiter: delimiter)[0]
//                suggestion = prefix.appending(delimiter).appending(suggestion)
//            }
//            self.suggestion = suggestion
//        } else {
//            self.suggestion = nil
//        }
//    }
//
//    // MARK: - Adjust Rects
//
////    override public func textRect(forBounds bounds: CGRect) -> CGRect {
////        return CGRect(x: bounds.origin.x + horizontalPadding, y: bounds.origin.y, width: bounds.size.width - (horizontalPadding * 2), height: bounds.size.height)
////    }
////
////    override public func editingRect(forBounds bounds: CGRect) -> CGRect {
////        return textRect(forBounds: bounds)
////    }
////
////    override public func placeholderRect(forBounds bounds: CGRect) -> CGRect {
////        return textRect(forBounds: bounds)
////    }
////
////    deinit {
////        removeTarget(self, action: #selector(autocompleteFieldDidChange(_:)), for: .editingChanged)
////    }
//}
