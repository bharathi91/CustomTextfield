//
//  EmailDomainnViewController.swift
//  SampleTestProject
//
//  Created by Bharathi's Macbook Air on 16/12/24.
//

import UIKit

class EmailDomainnViewController: UIViewController {

    @IBOutlet weak var emailTextField: UITextField!

       override func viewDidLoad() {
           super.viewDidLoad()

           // Add sample domains to the view
           let domainView = EmailDomainView()
           domainView.addDomain(domain: "example.com")
           domainView.addDomain(domain: "gmail.com")
           domainView.addDomain(domain: "outlook.com")

           emailTextField.inputAccessoryView = domainView
       }

}
