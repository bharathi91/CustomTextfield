//
//  DomainSuggestionsView.swift
//  SampleTestProject
//
//  Created by Bharathi's Macbook Air on 18/12/24.
//

import Foundation
import UIKit

class DomainSuggestionView: UIView {
    private let scrollView = UIScrollView()
    private var suggestionLabels = [UILabel]()

    override init(frame: CGRect) {
        super.init(frame: frame)
        setupSubviews()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    private func setupSubviews() {
        scrollView.frame = bounds
        addSubview(scrollView)
    }

    func updateSuggestions(with suggestions: [String]) {
        // Remove old labels
        suggestionLabels.forEach { $0.removeFromSuperview() }
        suggestionLabels.removeAll()

        // Add new labels
        var yOffset: CGFloat = 0
        for suggestion in suggestions {
            let label = UILabel()
            label.text = suggestion
            label.textColor = .black
            label.frame = CGRect(x: 0, y: yOffset, width: frame.width, height: 30)
            scrollView.addSubview(label)
            suggestionLabels.append(label)
            yOffset += 30
        }

        scrollView.contentSize = CGSize(width: frame.width, height: yOffset)
    }
}

// In your ViewController:
class YourViewController: UIViewController, UITextFieldDelegate {
    var emailTextField: UITextField!
    private let suggestionView = DomainSuggestionView()

    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupEmailTextField()
        // Add the suggestion view as a subview, initially hidden
        view.addSubview(suggestionView)
        suggestionView.isHidden = true
        suggestionView.backgroundColor = .blue
        // Observe keyboard notifications
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    func setupEmailTextField() {
        // Create and configure the email text field
        emailTextField = UITextField()
        emailTextField.placeholder = "Enter email address"
        emailTextField.delegate = self
        emailTextField.borderStyle = .roundedRect
        emailTextField.frame = CGRect(x: 20, y: 100, width: 300, height: 40)
        
        view.addSubview(emailTextField)
    }
    @objc func keyboardWillShow(notification: NSNotification) {
        if let keyboardSize = (notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue {
            suggestionView.frame = CGRect(x: 0, y: 300 , width: view.frame.width, height: 50)
            suggestionView.isHidden = false
        }
    }

    @objc func keyboardWillHide(notification: NSNotification) {
        suggestionView.isHidden = true
    }

    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let newText = (textField.text as NSString?)?.replacingCharacters(in: range, with: string) ?? ""

        // Generate domain suggestions based on newText
        let suggestions = generateDomainSuggestions(for: newText)
        suggestionView.updateSuggestions(with: suggestions)

        return true
    }

    // Implement the generateDomainSuggestions function to fetch suggestions from your backend or use a local algorithm
    private func generateDomainSuggestions(for text: String) -> [String] {
        // Example: Simple prefix matching
        let domains = ["gmail.com", "yahoo.com", "hotmail.com"]
        return domains.filter { $0.hasPrefix(text) }
    }
}
