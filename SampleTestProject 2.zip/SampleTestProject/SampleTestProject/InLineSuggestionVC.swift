//
//  InLineSuggestionVC.swift
//  SampleTestProject
//
//  Created by Bharathi's Macbook Air on 18/12/24.
//

import UIKit

class InLineSuggestionVC: UIViewController, UITextFieldDelegate {
    let suggestions = [ "red", "orange", "yellow", "green", "blue", "purple" ]
    let textField = UITextField()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        textField.frame = CGRect(x: 20, y: 100, width: self.view.frame.width - 40, height: 40)
        textField.layer.borderWidth = 1
        textField.layer.borderColor = UIColor.gray.cgColor
        textField.font = UIFont.systemFont(ofSize: 16)
        textField.autocorrectionType = .no
        textField.placeholder = "Enter email"
        textField.delegate = self
        view.addSubview(textField)
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        return !autoCompleteText( in : textField, using: string, suggestions: suggestions)
    }
    func autoCompleteText( in textField: UITextField, using string: String, suggestions: [String]) -> Bool {
        if !string.isEmpty,
           let selectedTextRange = textField.selectedTextRange,
           selectedTextRange.end == textField.endOfDocument,
           let prefixRange = textField.textRange(from: textField.beginningOfDocument, to: selectedTextRange.start),
           let text = textField.text( in : prefixRange) {
            let prefix = text + string
            let matches = suggestions.filter {
                $0.hasPrefix(prefix)
            }
            if (matches.count > 0) {
                textField.text = matches[0]
                if let start = textField.position(from: textField.beginningOfDocument, offset: prefix.count) {
                    textField.selectedTextRange = textField.textRange(from: start, to: textField.endOfDocument)
                    return true
                }
            }
        }
        return false
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
     textField.resignFirstResponder()
     return true
    }
}
