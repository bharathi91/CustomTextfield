//
//  AutoCompleteViewController3.swift
//  SampleTestProject
//
//  Created by Bharathi's Macbook Air on 18/12/24.
//

import UIKit

class AutoCompleteViewController3: UIViewController, UITextViewDelegate {
    
    // UITextView for email input
    let textView = UITextView()
    
    // Suggestions container
    var suggestionsView = UIView()
    var suggestionLabels: [UILabel] = []
    
    // List of email domains to suggest
    let emailDomains = ["gmail.com", "yahoo.com", "hotmail.com", "outlook.com", "icloud.com"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Setup UITextView
        textView.delegate = self
        textView.frame = CGRect(x: 20, y: 100, width: self.view.frame.width - 40, height: 40)
        textView.layer.borderWidth = 1
        textView.layer.borderColor = UIColor.gray.cgColor
        textView.font = UIFont.systemFont(ofSize: 16)
        textView.autocorrectionType = .no
        view.addSubview(textView)
        
        // Setup suggestions view (e.g., simple container)
        suggestionsView.frame = CGRect(x: textView.frame.origin.x, y: textView.frame.origin.y + textView.frame.height, width: textView.frame.width, height: 0)
        suggestionsView.backgroundColor = UIColor.white
        suggestionsView.layer.borderWidth = 1
        suggestionsView.layer.borderColor = UIColor.lightGray.cgColor
        view.addSubview(suggestionsView)
    }
    
    // UITextViewDelegate method to monitor text changes
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        // Allow text change
        let newText = (textView.text as NSString).replacingCharacters(in: range, with: text)
        filterSuggestions(for: newText)
        return true
    }
    
    // Filter and show suggestions
    func filterSuggestions(for text: String) {
        // Clear previous suggestions
        suggestionLabels.forEach { $0.removeFromSuperview() }
        suggestionLabels.removeAll()
        
        // Check if there is an '@' symbol and get the substring after '@'
        if let atSymbolRange = text.range(of: "@") {
            let domainPrefix = text[atSymbolRange.upperBound...]
            
            // Filter domains based on input
            let filteredDomains = emailDomains.filter { domain in
                domain.hasPrefix(String(domainPrefix))
            }
            
            // Create UILabels for each suggestion
            for (index, domain) in filteredDomains.enumerated() {
                let label = UILabel()
                label.text = domain
                label.frame = CGRect(x: 10, y: index * 30, width: Int(suggestionsView.frame.width) - 20, height: 30)
                label.font = UIFont.systemFont(ofSize: 14)
                label.textColor = .black
                label.isUserInteractionEnabled = true
                label.tag = index
                
                // Handle tap on suggestion
                let tapGesture = UITapGestureRecognizer(target: self, action: #selector(suggestionTapped(_:)))
                label.addGestureRecognizer(tapGesture)
                
                suggestionsView.addSubview(label)
                suggestionLabels.append(label)
            }
            
            // Adjust the height of the suggestions view
            suggestionsView.frame.size.height = CGFloat(filteredDomains.count * 30)
        } else {
            // Hide suggestions if no '@' symbol is present
            suggestionsView.frame.size.height = 0
        }
    }
    
    // Handle suggestion tap
    @objc func suggestionTapped(_ sender: UITapGestureRecognizer) {
        guard let label = sender.view as? UILabel else { return }
        
        // Get the selected domain
        let domain = emailDomains[label.tag]
        
        // Update textView with the selected domain
        if let atSymbolRange = textView.text.range(of: "@") {
            let username = textView.text.prefix(upTo: atSymbolRange.upperBound)
            textView.text = username + "@" + domain
        }
        
        // Hide suggestions after selection
        suggestionsView.frame.size.height = 0
    }
}

