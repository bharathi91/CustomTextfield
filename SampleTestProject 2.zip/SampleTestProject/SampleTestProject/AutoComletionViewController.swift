//
//  AutoComletionViewController.swift
//  SampleTestProject
//
//  Created by Bharathi's Macbook Air on 18/12/24.
//

import UIKit

class AutocompleteViewController: UIViewController, UITextViewDelegate {

    // UITextView for user input
    let textView = UITextView()
    
    // Custom UILabel to show the autocompletion suggestions
    let suggestionLabel = UILabel()
    
    // Sample list of possible words for autocompletion
    let possibleWords = ["apple", "banana", "orange", "pear", "peach", "pineapple", "plum", "grape", "grapefruit"]
    var filteredWords = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set up the textView for user input
        textView.frame = CGRect(x: 20, y: 100, width: self.view.frame.width - 40, height: 100)
        textView.delegate = self
        textView.layer.borderColor = UIColor.gray.cgColor
        textView.layer.borderWidth = 1.0
        textView.layer.cornerRadius = 8
        self.view.addSubview(textView)
        
        // Set up the suggestion label to display filtered words
        suggestionLabel.frame = CGRect(x: 20, y: textView.frame.maxY + 10, width: self.view.frame.width - 40, height: 30)
        suggestionLabel.textColor = .black
        suggestionLabel.font = UIFont.systemFont(ofSize: 16)
        suggestionLabel.isHidden = true  // Hide the suggestion label initially
        self.view.addSubview(suggestionLabel)
    }
    
    // UITextView Delegate Method - Detect text changes
    func textViewDidChange(_ textView: UITextView) {
        let text = textView.text ?? ""
        
        if text.count > 1 {
            // Filter words based on user input
            filteredWords = possibleWords.filter { $0.lowercased().hasPrefix(text.lowercased()) }
            
            // If there are suggestions, display them in the label
            if !filteredWords.isEmpty {
                suggestionLabel.isHidden = false
                suggestionLabel.text = filteredWords.joined(separator: ", ")
            } else {
                suggestionLabel.isHidden = true
            }
        } else {
            suggestionLabel.isHidden = true
        }
    }
    
    // Handling user tapping a suggestion (you can make it more sophisticated)
    @objc func suggestionTapped() {
        if !filteredWords.isEmpty {
            textView.text = filteredWords[0] // Auto-fill the first suggestion
            suggestionLabel.isHidden = true // Hide suggestions after selection
        }
    }
}

