//
//  AutoCompleteViewController2.swift
//  SampleTestProject
//
//  Created by Bharathi's Macbook Air on 18/12/24.
//

import UIKit


class AutocompleteViewController2: UIViewController, UITextViewDelegate {
    
    let textView = UITextView()
    var suggestionsContainer = UIView()
    var suggestionsLabels = [UILabel]()
    
    // Sample list of possible words
    let possibleWords = ["apple", "banana", "orange", "pear", "peach", "pineapple", "plum", "grape", "grapefruit"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Setup textView
        textView.frame = CGRect(x: 20, y: 100, width: self.view.frame.width - 40, height: 100)
        textView.delegate = self
        textView.layer.borderColor = UIColor.gray.cgColor
        textView.layer.borderWidth = 1.0
        textView.layer.cornerRadius = 8
        self.view.addSubview(textView)
        
        // Setup suggestions container (will hold the labels)
        suggestionsContainer.frame = CGRect(x: 20, y: textView.frame.maxY + 10, width: self.view.frame.width - 40, height: 0)
        self.view.addSubview(suggestionsContainer)
    }
    
    // UITextView Delegate Method - Detecting text changes
    func textViewDidChange(_ textView: UITextView) {
        let text = textView.text ?? ""
        
        if text.count > 1 {
            // Filter possible words
            let filteredWords = possibleWords.filter { $0.lowercased().hasPrefix(text.lowercased()) }
            
            // Show suggestions or hide them if no matches
            showSuggestions(filteredWords)
        } else {
            hideSuggestions()
        }
    }
    
    // Show filtered suggestions
    func showSuggestions(_ suggestions: [String]) {
        // Remove any previous labels
        for label in suggestionsLabels {
            label.removeFromSuperview()
        }
        
        // Clear the array
        suggestionsLabels.removeAll()
        
        // Create new labels for each suggestion
        for (index, suggestion) in suggestions.prefix(5).enumerated() {
            let label = UILabel()
            label.text = suggestion
            label.font = UIFont.systemFont(ofSize: 16)
            label.textColor = .black
            label.backgroundColor = .lightGray
            label.layer.cornerRadius = 5
            label.layer.masksToBounds = true
            label.frame = CGRect(x: 0, y: Int(CGFloat(index * 40)), width: Int(suggestionsContainer.frame.width), height: 30)
            label.isUserInteractionEnabled = true
            
            // Add tap gesture to select suggestion
            let tapGesture = UITapGestureRecognizer(target: self, action: #selector(didSelectSuggestion(_:)))
            label.addGestureRecognizer(tapGesture)
            
            suggestionsContainer.addSubview(label)
            suggestionsLabels.append(label)
        }
        
        // Update the container height to fit all suggestions
        suggestionsContainer.frame.size.height = CGFloat(suggestionsLabels.count * 40)
    }
    
    // Hide suggestions
    func hideSuggestions() {
        // Remove any previous labels
        for label in suggestionsLabels {
            label.removeFromSuperview()
        }
        
        suggestionsLabels.removeAll()
        suggestionsContainer.frame.size.height = 0
    }
    
    // Handle suggestion selection
    @objc func didSelectSuggestion(_ gesture: UITapGestureRecognizer) {
        guard let label = gesture.view as? UILabel else { return }
        textView.text = label.text
        hideSuggestions()
    }
}

