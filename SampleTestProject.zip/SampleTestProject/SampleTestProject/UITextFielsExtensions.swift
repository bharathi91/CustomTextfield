import UIKit

extension UITextField: UITextFieldDelegate {
    
    private struct AssociatedKeys {
        static var suggestionsView = "suggestionsView"
        static var suggestionLabels = "suggestionLabels"
        static var emailDomains = "emailDomains"
    }
    
    private var suggestionsView: UIView? {
        get {
            return objc_getAssociatedObject(self, &AssociatedKeys.suggestionsView) as? UIView
        }
        set {
            objc_setAssociatedObject(self, &AssociatedKeys.suggestionsView, newValue, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
        }
    }
    
    private var suggestionLabels: [UILabel]? {
        get {
            return objc_getAssociatedObject(self, &AssociatedKeys.suggestionLabels) as? [UILabel]
        }
        set {
            objc_setAssociatedObject(self, &AssociatedKeys.suggestionLabels, newValue, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
        }
    }
    
    private var emailDomains: [String]? {
        get {
            return objc_getAssociatedObject(self, &AssociatedKeys.emailDomains) as? [String]
        }
        set {
            objc_setAssociatedObject(self, &AssociatedKeys.emailDomains, newValue, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
        }
    }
    
    // Setup for the email domain suggestions
    func setupEmailAutocomplete(with domains: [String]) {
        self.emailDomains = domains
        self.delegate = self
        
        // Create and configure the suggestions view
        let suggestionsView = UIView()
        suggestionsView.backgroundColor = .white
        suggestionsView.layer.borderWidth = 1
        suggestionsView.layer.borderColor = UIColor.lightGray.cgColor
        suggestionsView.layer.cornerRadius = 5
        suggestionsView.isHidden = true
        self.superview?.addSubview(suggestionsView)
        
        self.suggestionsView = suggestionsView
        self.suggestionLabels = []
        
        // Add observers for text changes
        NotificationCenter.default.addObserver(self, selector: #selector(textFieldDidChange), name: UITextField.textDidChangeNotification, object: self)
    }
    
    // Handle text changes
    @objc private func textFieldDidChange() {
        guard let text = self.text else { return }
        filterSuggestions(for: text)
    }
    
    // Filter and show domain suggestions
    private func filterSuggestions(for text: String) {
        // Remove previous suggestions
        suggestionLabels?.forEach { $0.removeFromSuperview() }
        suggestionLabels?.removeAll()
        
        guard let emailDomains = emailDomains else { return }
        
        // Check if '@' exists and filter domains
        if let atSymbolRange = text.range(of: "@") {
            let domainPrefix = text[atSymbolRange.upperBound...]
            
            // Filter the domains based on the user's input
            let filteredDomains = emailDomains.filter { domain in
                domain.hasPrefix(String(domainPrefix))
            }
            
            // Create labels for each suggestion
            for (index, domain) in filteredDomains.enumerated() {
                let label = UILabel()
                label.text = domain
                label.frame = CGRect(x: 10, y: CGFloat(index) * 30, width: self.superview?.frame.width ?? 0, height: 30)
                label.font = UIFont.systemFont(ofSize: 14)
                label.textColor = .black
                label.isUserInteractionEnabled = true
                label.tag = index
                
                let tapGesture = UITapGestureRecognizer(target: self, action: #selector(suggestionTapped(_:)))
                label.addGestureRecognizer(tapGesture)
                
                suggestionsView?.addSubview(label)
                suggestionLabels?.append(label)
            }
            
            // Adjust the height of the suggestions view based on the number of suggestions
            let maxSuggestions = min(filteredDomains.count, 5)  // Limit the number of visible suggestions
            let suggestionsHeight: CGFloat = CGFloat(maxSuggestions * 30)
            suggestionsView?.frame.size.height = suggestionsHeight
            suggestionsView?.frame.origin.y = self.frame.origin.y + self.frame.height + 5
            
            // Ensure the suggestions view stays within the screen bounds
            let screenHeight = UIScreen.main.bounds.height
            let availableHeight = screenHeight - (self.frame.origin.y + self.frame.height + 20)  // 20px margin
            
            if suggestionsHeight > availableHeight {
                suggestionsView?.frame.size.height = availableHeight
            }
            
            suggestionsView?.isHidden = false
        } else {
            // Hide suggestions if '@' symbol is not present
            suggestionsView?.isHidden = true
        }
    }
    
    // Handle suggestion tap
    @objc private func suggestionTapped(_ sender: UITapGestureRecognizer) {
        guard let label = sender.view as? UILabel else { return }
        
        // Get the selected domain
        guard let domain = emailDomains?[label.tag] else { return }
        
        // Update the text field with the selected domain
        if let atSymbolRange = self.text?.range(of: "@") {
            let username = self.text?.prefix(upTo: atSymbolRange.upperBound) ?? ""
            self.text = username + "@" + domain
        }
        
        // Hide suggestions after selection
        suggestionsView?.isHidden = true
    }
    
    // Cleanup
//    deinit {
//        NotificationCenter.default.removeObserver(self, name: UITextField.textDidChangeNotification, object: self)
//    }
}
