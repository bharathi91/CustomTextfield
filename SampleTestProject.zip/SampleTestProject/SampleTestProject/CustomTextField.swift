import UIKit

class DomainSuggestionTextField: UITextField, UITableViewDelegate, UITableViewDataSource {
    
    // Domain suggestions
    private var domainSuggestions = ["gmail.com", "yahoo.com", "outlook.com", "icloud.com", "hotmail.com"]
    private var filteredSuggestions: [String] = []
    
    // Table view to display domain suggestions
    private var suggestionsTableView: UITableView!
    
    // To track the keyboard height
    private var keyboardHeight: CGFloat = 0.0
    
    // Initialization
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupTableView()
        self.delegate = self
        addKeyboardObservers()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupTableView()
        self.delegate = self
        addKeyboardObservers()
    }
    
    func setupTableView() {
        // Initialize table view
        suggestionsTableView = UITableView()
        suggestionsTableView.delegate = self
        suggestionsTableView.dataSource = self
        suggestionsTableView.isHidden = true
        suggestionsTableView.register(UITableViewCell.self, forCellReuseIdentifier: "DomainCell")
        
        // Add table view to the view hierarchy
        if let parentView = self.superview {
            parentView.addSubview(suggestionsTableView)
        }
    }
    
    // Register keyboard observers to adjust table view position
    private func addKeyboardObservers() {
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(_:)), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    @objc private func keyboardWillShow(_ notification: Notification) {
        if let userInfo = notification.userInfo,
           let keyboardFrame = userInfo[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect {
            keyboardHeight = keyboardFrame.height
            adjustTableViewPosition()
        }
    }
    
    @objc private func keyboardWillHide(_ notification: Notification) {
        keyboardHeight = 0.0
        adjustTableViewPosition()
    }
    
    // Adjust the position of the table view
    private func adjustTableViewPosition() {
        guard let parentView = self.superview else { return }
        
        // Get the current position of the text field relative to the parent view
        let textFieldPosition = self.convert(self.bounds.origin, to: parentView)
        let tableViewY = textFieldPosition.y + self.frame.height
        
        // Set the table view's position just above the keyboard
        suggestionsTableView.frame = CGRect(x: textFieldPosition.x, y: tableViewY - keyboardHeight, width: self.frame.width, height: 150)
        suggestionsTableView.isHidden = filteredSuggestions.isEmpty
    }
    
    // Detect changes in the text field
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        // Get the current text
        var currentText = textField.text ?? ""
        
        // Update the current text with the new character
        if let range = Range(range, in: currentText) {
            currentText.replaceSubrange(range, with: string)
        }
        
        // Filter the domain suggestions based on the input after '@'
        filterSuggestions(text: currentText)
        
        return true
    }
    
    // Filter domain suggestions based on text input
    private func filterSuggestions(text: String) {
        // Check if '@' exists
        if let atIndex = text.firstIndex(of: "@") {
            let domainPart = text[text.index(after: atIndex)...]
            filteredSuggestions = domainSuggestions.filter { $0.hasPrefix(String(domainPart)) }
            suggestionsTableView.isHidden = filteredSuggestions.isEmpty
        } else {
            filteredSuggestions = []
            suggestionsTableView.isHidden = true
        }
        
        suggestionsTableView.reloadData()
    }
    
    // Table view data source methods
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredSuggestions.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DomainCell", for: indexPath)
        cell.textLabel?.text = filteredSuggestions[indexPath.row]
        return cell
    }
    
    // Table view delegate method (to handle domain selection)
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let text = self.text, let atIndex = text.firstIndex(of: "@") {
            let domain = filteredSuggestions[indexPath.row]
            self.text = text.prefix(upTo: atIndex) + "@" + domain
        }
        suggestionsTableView.isHidden = true
    }
    
    // Cleanup observers
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
}
